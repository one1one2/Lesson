var searchData=
[
  ['set_5fboundrary',['set_Boundrary',['../classHeat.html#a5277a27b4f971ed54e66d8fe8ffe97f7',1,'Heat']]],
  ['set_5fcfl',['set_CFL',['../classHeat.html#ad50289d77a5715fa1aa63af60956ae26',1,'Heat']]],
  ['set_5ff',['set_f',['../classHeat.html#a3b7d978b4d27645c6f6bacd55c8cdbc2',1,'Heat']]],
  ['set_5finitial',['set_Initial',['../classHeat.html#a7dbbbb774cb0317d18a31342ce8e6865',1,'Heat']]],
  ['set_5fn',['set_N',['../classHeat.html#af7b0ad84d2b149a944bada144c3e450f',1,'Heat']]],
  ['set_5frank',['set_rank',['../classHeat.html#a95a5f94ca3965c0ba13ea1258eea31e4',1,'Heat']]],
  ['set_5fsize',['set_size',['../classHeat.html#abea1c1c77c8fd8654c9cdef12a238eeb',1,'Heat']]],
  ['set_5fsolution',['set_Solution',['../classHeat.html#af702ba3e9068a9b680e72a2e83591a48',1,'Heat']]],
  ['set_5ft',['set_t',['../classHeat.html#a890e689eed8ad3992ff8b50dae40cace',1,'Heat']]],
  ['solve',['solve',['../classHeat.html#af166af7cfc6e7a3118ac97be84c0c75b',1,'Heat']]]
];
