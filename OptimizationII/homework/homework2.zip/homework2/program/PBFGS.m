function [x,f,info] = PBFGS(fun,num,U,Point)
path(path,'linesearch');

x = Point;
n = length(x);
m = length(num);
% num 为每个分块对应的秩，共m个分块

epsilon_f = 1e-25;
epsilon_g = 1e-15;
step = 10000;

info.ite=0; 
info.feva=0;
info.err=0;


[f0 g] = fun(x);
while (1==1)
  if info.ite>=step info.err=1; break; end  
  [f, g] = fun(x);
  if norm(g) <= epsilon_g info.err=2; break; end 
  
  for i = 1:m
    B(:,:,i) = eye(num(i));
  end 
  if (info.ite > 0)
    for i=1:m
      temp = B(:,:,i)*U(s,i);
      B(:,:,i) = B(:,:,i) - (temp*temp')/(U(s,i)'*temp)...
      +U(y,i)*U(y,i)'/(U(y,i)'*U(s,i));
    end 
  end 
  d = -cgs(@(s)Bfun(s,m,U,B),g,1e-10,100); 

  d = d/norm(d);
  if g'*d > 0   d = -d; end
  %Rule.opt(1) = 0;
  %Rule.opt = bodfltchk(Rule.opt, [0 10 25 1e-4]);
  Rule.opt(1) = 1;
  Rule.opt = bodfltchk(Rule.opt, [1 1e-4 10 0.95 0.05]);
  Rule.crtr = @boarmgld;
  Rule.mthd = @bointrplt33;
  [alpha,info1,perf] = bolinesearch(fun,x,d,Rule);
  info.feva=info.feva+info1(3)+1;

  info.ite=info.ite+1; 
  s = perf.x - x;
  y = perf.g - g;

  f1=perf.F;
  x=perf.x;
  g=perf.g;
  if abs(f0-f1)<=epsilon_f break; end 
  f0=f1
end
f=fun(x);
end


function y = Bfun(s,m,U,B)
  y = zeros(size(s));
  for i = 1:m
    temp = U(i,s,1);
    temp = B(:,:,i)*temp; 
    y = y + U(i,temp,-1);
  end 
end 

