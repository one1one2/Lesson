function [F g] = S303(x)

n = length(x);
F = 0;
s = 0;
g = 2*x;

for i = 1:n
  s = s+ i*x(i)/2;
  F = F + x(i)^2;
end 
F = F + s^2 + s^4;
for i = 1:n
  g(i) = g(i) + s*i + 2*s^3*i;
end
end 
