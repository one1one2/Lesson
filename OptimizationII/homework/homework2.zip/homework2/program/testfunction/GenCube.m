function [F g] = GenCube(x)

n = length(x);
g = zeros(n,1);
F = (x(1) - 1)^2;
g(1) = 2*(x(1)-1);
for i = 2:n
  F = F + 100*(x(i)-x(i-1)^3)^2; 
  g(i) = g(i) + 200*(x(i)-x(i-1)^3);
  g(i-1) = g(i-1) - 200*(x(i)-x(i-1)^3)*(3*x(i-1)^2); 
end 

end 
